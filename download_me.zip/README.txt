download the rar file
unzip it
then open the .html "index" file with chrome